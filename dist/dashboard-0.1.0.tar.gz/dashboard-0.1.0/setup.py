# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src'}

packages = \
['dashboard']

package_data = \
{'': ['*']}

install_requires = \
['plotly>=5.4.0,<6.0.0', 'pytest>=6.2.5,<7.0.0', 'streamlit>=1.2.0,<2.0.0']

setup_kwargs = {
    'name': 'dashboard',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'None',
    'author_email': None,
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
